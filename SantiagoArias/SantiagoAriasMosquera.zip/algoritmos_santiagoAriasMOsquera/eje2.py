suma = 0
contador = 0

while(contador <= 100):
    if(contador == suma):
        print(suma)
        contador = contador + 1

        
    else:
        suma = suma + contador
        contador = contador + 1
    pass
    
##print(contador)
#print(suma)



#cadena = f"{i} + {i} = {suma}"
#print(cadena)

#while(suma == i):
    #print(f"{cadena} = {suma}")
   