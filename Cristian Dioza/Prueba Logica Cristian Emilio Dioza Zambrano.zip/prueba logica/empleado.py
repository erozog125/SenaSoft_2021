
def horas():
    horasNocturnas=input("Ha trabajado horas nocturnas este mes? si/no : ")
    if horasNocturnas.lower()=="no":
        print("usted no tiene derecho a bonificación este mes")
    elif horasNocturnas.lower()=="si":
        horasNocturnaTrabajada=int(input("Ingrese el número de horas nocturnas trabajadas: "))
        pago=horasNocturnaTrabajada*2000
        print("su bonificación este mes es de: {0} pesos".format(pago))
    else :
        print("Ingrese un valor valido")
        horas()

#Execución
horas()


