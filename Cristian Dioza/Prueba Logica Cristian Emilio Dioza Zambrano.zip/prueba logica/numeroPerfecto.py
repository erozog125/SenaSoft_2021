#Función número perfecto
def numeroPerfecto(numero):
    i=1
    numeroP=0
    while(i<numero):
        if(numero%i==0):
            numeroP+=i
        i+=1
    if(numero==numeroP):
        print("Es un número perfecto  el %d" % numeroP)
#Función de Pruebas
def pruebaUnitaria():
    i=1
    while(i<1000):
        numeroPerfecto(i)
        i+=1

pruebaUnitaria()