switch = True

while switch == True:

    opcion = int(input('Ingrese una opcion, 1 para el problema 1 o 2 para el problema 2'))

    # problema 1
    if(opcion == 1):

        def Bonificacion(horas):
            if(confirmacion == 1):   
                bonificacion = 2000 * horas
                return bonificacion

        nombre = input('Ingrese su nombre: ')

        print('¿A trabajado horas nocturnas? seleccione 1 para SI o 2 NO')

        confirmacion = int(input(''))

        if confirmacion == 1:  
            print('Ingrese el numero de horas nocturnas')  
            horas = int(input(''))
            print('Su bonificacion de este mes es de: ',Bonificacion(horas))
        else:
            print('usted no tiene derecho a bonificacion este mes')

    # problema 2
    elif( opcion == 2):

        mensaje = ""

        suma = 0

        result_suma = ""
        resultado =""

        for i in range(1,1000):
            if(i % 2 == 0):
                while suma <= i:     
                    suma = suma + 1      
                    result_suma = result_suma + " + " + str(suma)     
                    if(suma == i):
                        resultado = resultado + result_suma + " = " + str(i) 

        print(resultado)

    elif(opcion == 3):
        
        switch = False


