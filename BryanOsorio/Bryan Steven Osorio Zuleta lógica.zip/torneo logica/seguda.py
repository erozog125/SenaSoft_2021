
def numeroPerfecto():
    contador = 0
    Numero1 =  1
    while (contador < 1000):
        contador = contador + 1
        Numero1 = Numero1 + 1
        numeros = Numero1 / 2
        suma = Numero1 + contador
        print("Los numeros perfectos son: " + str(suma))



        #disculpar, no pude.
        #perfecto = numeros /2
        #suma = numeros + contador
        #if perfecto == numeroPerfecto:
        #if numeroPerfecto/2 + (contador) == numeroPerfecto:
        #print("Los numeros perfectos son: " + str(perfecto))

numeroPerfecto()
