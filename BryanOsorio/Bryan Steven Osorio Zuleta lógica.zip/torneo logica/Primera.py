opcionElegir=int(input("Ingrese 1 si el empleado ha trabajado horas nocturnas este mes, de lo contrario ingrese 2: "))
valorExtra = 2000
def horasTrabajadas():
    if (opcionElegir == 1):
        horasNocturnas = float(input("Ingrese el total de las horas trabajadas en el horario nocturno: "))
        totalNocturas = valorExtra * horasNocturnas
        print("Su bonificación extra por las horas nocturnas trabajas es de: ", str(totalNocturas), " pesos.")
        consultar =  int(input("Ingrese 1 si quiere volver a repetir el proceso, ingrese 2 si quiere finalizar el proceso: "))
        if (consultar ==1):
            horasTrabajadas()
        else:
            print("Proceso finalizado.")
            exit
    if (opcionElegir ==2):
        print("Usted no tiene derecho a bonificación este mes")
        exit

horasTrabajadas()
