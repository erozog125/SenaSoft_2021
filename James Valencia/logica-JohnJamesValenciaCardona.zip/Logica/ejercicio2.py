
"""
John James Valencia Cardona
CC 1 096 040 574
ADSI 2236347
2021
"""

"""
Un número perfecto es aquel cuya suma de sus divisores(no se incluye el mismo número)es igual a él mismo. Por ejemplo, 6
es un número perfecto, ya que los divisores de 6 son el 1, el 2 , y el 3 y al sumar estos divisores obtenemos el mismo
número: 1 + 2 + 3 = 6. Cree un programa que muestre los números perfectos entre 1 y mil.

"""
from numbers import Number
from utils.funciones import es_numero

def main():
    # Muestro un mensaje de bienvenida
    print("Bienvenido al programa que visualiza los números perfectos entre 1(uno) y 1000(mil)")
    print()

    proceso_principal()
    
    # Mensaje de despedida
    print()
    print("-"*50)

    print("Gracias por usar nuestro programa: ")
    print("Programa elaborado por John James Valencia Cardona (dunas26) - 2021")

def proceso_principal():
    print("Los siguientes son números perfectos")

    # Creo la variable para calcular la cantidad de números perfectos
    encontrar_perfectos(1, 1000)

def encontrar_perfectos(min, max):
    if not es_numero(min) or not es_numero(max):
        print("Ha ingresado un valor que no es un número")

    # Corrijo los valores si están trocados
    if min > max:
        print(f"Los valores de min -> ({min}) y max -> ({max}) están invertidos, corrigiendo...")
        temp = max
        max = min
        min = temp

    cantidad_numeros_perfectos = 0

    # Realizo el proceso
    for i in range(min, max + 1):
        if es_numero_perfecto(i):
            print(i)
            cantidad_numeros_perfectos += 1
            print()

    print(f"Entre {min} y {max} hay {cantidad_numeros_perfectos} números perfectos")

def es_numero_perfecto(numero):
    if not es_numero(numero):
        return

    # Numero perfecto
    if numero == 1:
        return False
    
    # Obtengo un arreglo con los divisores del número
    divisores = obtener_arreglo_divisores(numero)

    if len(divisores) <= 0:
        return False
    else:
        # Sumo los divisores
        suma_divisores = sum(divisores)
        
        
        cadena_divisores = " + ".join(map(str, divisores))
        
        if suma_divisores == numero:
            print(cadena_divisores + " = ")
        # Verifico si es un número perfecto
        return suma_divisores == numero

def es_divisor(divisor, numero):
    return numero % divisor == 0

def obtener_arreglo_divisores(numero):
    if not es_numero(numero):
        return 

    # Incluyo el 1 porque es divisor de todos los números
    divisores = [1]

    for i in range(2, numero):
        if es_divisor(i, numero):
            divisores.append(i)

    return divisores

if __name__ == "__main__":
    main()