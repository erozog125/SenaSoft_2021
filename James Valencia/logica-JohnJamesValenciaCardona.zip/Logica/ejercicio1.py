"""
John James Valencia Cardona
CC 1 096 040 574
ADSI 2236347
2021
"""

"""
En una empresa, los empleados trabajan en horario normal de 08:00 a.m. a 12:00 p.m. y de 02:00 p.m. a 06:00 p.m. Sin
embargo, algunos trabajadores trabajan horas nocturnas (después de las 06:00 p.m.), por las cuales tienen derecho a una
bonificación de $2.000 (dos mil pesos) por hora nocturna trabajada. Cree en un programa que, primero pregunte al usuario
si el trabajador ha trabajado horas nocturnas este mes, en caso de no haberlas trabajado el programa debe mostrar el
siguiente mensaje: “usted no tiene derecho a bonificación este mes”. Si el trabajador ha trabajado horas nocturnas durante
el mes, entonces el programa debe solicitar al usuario el número de horas nocturnas trabajadas y luego mostrar un mensaje
con el valor de la bonificación a la que tiene derecho el trabajador, por ejemplo: “su bonificación este mes es de: 80000
pesos”.
"""

from utils.funciones import entrada_dato

VALOR_HORA_NOCTURNA = 2000

def main():
    # Muestro un mensaje de bienvenida
    print("Bienvenido al programa para calcular horas nocturnas trabajadas")
    print()

    proceso_principal()
    
    # Mensaje de despedida
    print()
    print("-"*50)

    print("Gracias por usar nuestro programa")
    print("Programa elaborado por John James Valencia Cardona (dunas26) - 2021")

def proceso_principal():
    # Inicializo el valor de horas nocturnas para evitar el UnboundLocalError
    horas_nocturnas = 0
    error = False
    entrada_horas_nocturnas = None
    trabajado_horas_nocturnas = None

    try:
        trabajado_horas_nocturnas = entrada_dato("¿Ud ha trabajado horas nocturnas este mes? (s/N -> La opción por defecto es NO): ").lower()

        # Si el dato que ingresa por consola es un espacio vacío
        if not trabajado_horas_nocturnas or trabajado_horas_nocturnas.isspace():
            print("NO")
    except KeyboardInterrupt:
        print()
        print("X"*50)
        print("Ha cancelado la ejecución del programa")
        return

    print("-"*50)
    print()

    # Si no ha trabajado horas nocturnas (Decisión por defecto es NO)
    if trabajado_horas_nocturnas != "s":
        print("Usted no tiene derecho a bonificación este mes")
        return


    # Hago el proceso de conversion de horas nocturnas
    try:
        entrada_horas_nocturnas = entrada_dato("Ingrese la cantidad de horas nocturnas trabajadas: ")
    except KeyboardInterrupt:
        print()
        print("X"*50)
        print("Ha cancelado la ejecución del programa")
        return

    # Compruebo que el usuario no ingrese valores incorrectos
    try:
        horas_nocturnas = int(entrada_horas_nocturnas)
    except ValueError:
        print("No se ha ingresado un valor válido")
        error = True
    except KeyboardInterrupt:
        print()
        print("X"*50)
        print("Ha cancelado la ejecución del programa")
        return

    print()
    # Si no ha trabajado horas nocturnas
    if horas_nocturnas <= 0:
        print("Ha ingresado un valor de horas no permitido, solo se permite 1 o más horas")
        error = True
    else:
        # Si no ha trabajdo horas nocturnas
        print("Calculando su bonificación...")
        bonificacion_horas = calcular_bonificacion_horas(horas_nocturnas, VALOR_HORA_NOCTURNA)

        print("Su bonificación de horas nocturnas corresponde a:\n")
        print(f"Bonificación: ${bonificacion_horas}")
        print(f"Horas trabajadas: {horas_nocturnas} hora(s)")
        print(f"Valor de la hora: ${VALOR_HORA_NOCTURNA}")

    # Si existe un error
    if error:
        if entrada_horas_nocturnas:
            print(f"VALOR INGRESADO: \"{entrada_horas_nocturnas}\"")
        else:
            print(f"VALOR INGRESADO: No ingresado")

def calcular_bonificacion_horas(numero_horas, valor_hora):
    return numero_horas * valor_hora

if __name__ == "__main__":
    main()