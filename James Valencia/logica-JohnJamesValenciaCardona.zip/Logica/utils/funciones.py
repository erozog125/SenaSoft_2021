from numbers import Number

def entrada_dato(mensaje):
    try:
        return input(mensaje)
    except EOFError: # Si hay un error de Fin de Linea (EOF) retorno un string vacío
        return ""

def es_numero(numero):
    return isinstance(numero, Number)