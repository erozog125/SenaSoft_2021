'''Un número perfecto es aquel cuya suma de sus divisores(no se incluye el mismo número)
es igual a él mismo. Por ejemplo, 6 es un número perfecto, ya que los divisores de
6 son el 1, el 2 , y el 3 y al sumar estos divisores obtenemos el mismo 
número: 1 + 2 + 3 = 6. Cree un programa que muestre los números perfectos entre 1 y mil.'''


for i in range(1000):
    print(i)
    