'''Problema 1:
En una empresa, los empleados trabajan en horario normal de 08:00 a.m. a 12:00 p.m.
y de 02:00 p.m. a 06:00 p.m. Sinembargo, algunos trabajadores 
trabajan horas nocturnas (después de las 06:00 p.m.),
por las cuales tienen derecho a una bonificación de $2.000 (dos mil pesos)
por hora nocturna trabajada.

## Cree en un programa que, primero pregunte al usuario
si el trabajador ha trabajado horas nocturnas este mes, en caso de no haberlas
 trabajado el programa debe mostrar el siguiente mensaje:
“usted no tiene derecho a bonificación este mes”.
Si el trabajador ha trabajado horas nocturnas durante
el mes, entonces el programa debe solicitar al usuario el número de horas nocturnas
trabajadas y luego mostrar un mensaje con el valor de la bonificación a la que
tiene derecho el trabajador, por ejemplo: “su bonificación este mes es de: 80000
pesos”.'''


def desicion_horas_trabajadas(pregunta_horas,lista):
    if pregunta_horas == lista[0] or pregunta_horas == lista[1] or pregunta_horas == lista[2]:
        return input("¿Cuantas horas ha tranbajado en el mes?: ")
    elif pregunta_horas=="no" or pregunta_horas=="NO" or pregunta_horas=="2":
         print(">>>>> Usted no tiene derecho a bonificación este mes <<<<<")
    else:
        print("Ingreso un dato incorrecto")


def proceso (horas_trabajadas):
    proceso = horas_trabajadas * 2000
    return proceso




#-----------------------
#llamar funciones

print("\n\t Bienvenido al programa SENASOFT\n-------------------------")
print("1)Si\n2)No")

lista = ["si","Si","1"]

try:
    pregunta_horas = input(str("Ha trabajado horas nocturnas?: "))
except NameError:
    print("XXXX Ingreso un dato no valido XXXX")
    exit()

horas_trabajadas = desicion_horas_trabajadas(pregunta_horas, lista)
bonificacion = proceso(horas_trabajadas)
mensaje_final = f"Su bonificacion es de {bonificacion}"
