""" Problema 2:
Un número perfecto es aquel cuya suma de sus divisores(no se incluye el mismo número)es igual a él mismo. Por ejemplo, 6
es un número perfecto, ya que los divisores de 6 son el 1, el 2 , y el 3 y al sumar estos divisores obtenemos el mismo
número: 1 + 2 + 3 = 6. Cree un programa que muestre los números perfectos entre 1 y mil."""

lista = []


limite = 1000
contador = 0

while contador < limite:
    iteracion = 1   
    while (iteracion < (contador/iteracion)):
        modulo = contador % iteracion
        if  modulo != 0 and modulo != contador:
            lista.append(modulo)
        iteracion = iteracion + 1
    contador = contador + 1

print(lista)


"""
diccionario = {}


limite = 1000
contador = 0

while contador < limite:
    iteracion = 1   
    while (iteracion < (contador/iteracion)):
        modulo = contador % iteracion
        if  modulo != 0 and modulo != contador:
            dicicionario["contador"] = [modulo]
        iteracion = iteracion + 1
    contador = contador + 1

print(diccionario)

"""