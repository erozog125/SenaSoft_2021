def EsDivisor(divisor, numPerfecto):
    if numPerfecto%divisor == 0:
        return True
    else:
        return False

def EsPerfecto(numero):

    listaDivisores= []

    for i in range(1,numero):
        resulEsDivisor= EsDivisor(i,numero)
        if resulEsDivisor == True:
            listaDivisores.append(i)
    
    if sum(listaDivisores)== numero:
        return True
    else: 
        return False



"------------------"



listaPerfectos= []

for i in range(1,1001):
    nuevoPerfecto= EsPerfecto(i)
    if nuevoPerfecto == True:
        listaPerfectos.append(i)

print(listaPerfectos)



