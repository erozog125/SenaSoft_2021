def BonoHoraNocturna(horasTrabajadas):
    resulHorasTrabajadas= ValidarNum(horasTrabajadas)
    if resulHorasTrabajadas != False:
        bonificacion= resulHorasTrabajadas*2000
        return bonificacion
    else:
        return False

def ValidarNum(numero):
    try:
        numero= int(numero)
    except ValueError:
        numero= False
    return numero

numValido= False


while True:
    TrabajaExtra= input("¿Ha trabajado horas extra este mes?:  digite 1 para Sí  digite 2 para No ")
    resulTrabajaExtra= ValidarNum(TrabajaExtra)
    if resulTrabajaExtra == 1:
        while numValido == False:
            horasTrabajadas= input("Digite el número de horas extra que trabajó este mes: ")
            horasValidas=ValidarNum(horasTrabajadas)
            if horasValidas != False:
                numValido= True
                bonificacion= BonoHoraNocturna(horasTrabajadas)
                print("Su bonificación este mes tiene un valor de "+str(bonificacion)+" pesos")
                print("----------------")
                continuarProg= input("¿Desea calcular la bonificación de otro usuario?:  digite 1 para No  digite otro numero para Sí ")
                resulContinuarProg= ValidarNum(continuarProg)
                if resulContinuarProg== 1:
                    break
            else:
                print("Digite un número real")
        
    elif resulTrabajaExtra == 2:
        print("Usted no tiene derecho a bonificación este mes")
        print("----------------")
        continuarProg= input("¿Desea calcular la bonificación de otro usuario?:  digite 1 para No  digite otro numero para Sí ")
        resulContinuarProg= ValidarNum(continuarProg)
        if resulContinuarProg== 1:
            break
    else:
        print("Digíte un número válido")

    